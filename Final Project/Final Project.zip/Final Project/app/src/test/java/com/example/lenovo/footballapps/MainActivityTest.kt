package com.example.lenovo.footballapps

import com.example.lenovo.footballapps.Api.ApiRepository
import com.example.lenovo.footballapps.Api.TheSportDbApi
import com.example.lenovo.footballapps.Fragment.NextMatch.NextMatchPresenter
import com.example.lenovo.footballapps.Fragment.NextMatch.NextMatchView
import com.example.lenovo.footballapps.Model.Match.Match
import com.example.lenovo.footballapps.Model.Match.MatchResponse
import com.google.gson.Gson
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class MainActivityTest{
    @Mock
    private lateinit var Api : ApiRepository
    @Mock
    private lateinit var presenter: NextMatchPresenter
    @Mock
    private lateinit var gson: Gson
    @Mock
    private lateinit var view: NextMatchView

    @Before
    fun setup(){
        MockitoAnnotations.initMocks(this)
        presenter = NextMatchPresenter(view, Api, gson, TestContextProvider())

    }
    @Test
    fun getNextMatch(){
        val dataMatch : MutableList<Match> = mutableListOf()
        val response = MatchResponse(dataMatch)
        val id = "1234"
        Mockito.`when`(gson.fromJson(Api.doRequest(TheSportDbApi.getNextMatch(id)), MatchResponse::class.java))
                .thenReturn(response)
        presenter.getNextMatch(id)

        Mockito.verify(view).showLoading()
        Mockito.verify(view).showNextMatchList(response.matchs)
    }
}